"""
Desktop launcher: Flask in a thread + pywebview window.
Save-file dialogs via js_api (DesktopApi). See docs/documentation.md.
"""

import logging
import os
import shutil
import socket
import sys
import threading
import time
import traceback
from pathlib import Path

import webview

from core.flask_app import create_app
from python_scripts import config

APP_SUPPORT_DIR = config.APP_SUPPORT_DIR
LOG_DIR = config.LOG_DIR
LOG_FILE = LOG_DIR / "digiterra.log"


class DesktopApi:
    def __init__(self, output_dir: Path, window=None) -> None:
        self.output_dir = output_dir
        self.window = window
        self._saving = False

    def test_api(self) -> str:
        try:
            return "API is working"
        except Exception as error:
            logging.error("Error in test_api: %s", error)
            return "API error"

    def save_file(self, filename: str, download_name: str | None = None) -> bool:
        if self._saving:
            logging.info("save_file called while another save is in progress; ignoring")
            return False

        self._saving = True
        try:
            # filename arrives from page JavaScript. Path's / operator discards the
            # base when the right operand is absolute, so an unchecked value here
            # would copy any file the user can read to wherever the dialog points.
            base = Path(self.output_dir).resolve()
            source_path = (base / filename).resolve()
            try:
                source_path.relative_to(base)
            except ValueError:
                logging.error("Refusing download outside the output directory: %s", filename)
                return False
            if not source_path.is_file():
                logging.error("Download source not found: %s", source_path)
                return False

            window = self.window
            if window is None:
                try:
                    if webview.windows:
                        window = webview.windows[0]
                        self.window = window
                except (AttributeError, IndexError) as e:
                    logging.warning("Could not access webview.windows: %s", e)

            result = None
            if window:
                try:
                    result = window.create_file_dialog(
                        webview.SAVE_DIALOG,
                        save_filename=download_name or filename,
                    )
                    logging.debug("File dialog opened using window instance")
                except Exception as e:
                    logging.warning("Window-based file dialog failed, trying module-level: %s", e)

            if result is None:
                try:
                    result = webview.create_file_dialog(
                        webview.SAVE_DIALOG,
                        save_filename=download_name or filename,
                    )
                    logging.debug("File dialog opened using module-level function")
                except Exception as e:
                    logging.error("Both file dialog methods failed: %s", e)
                    return False

            if not result:
                logging.info("User cancelled file save dialog")
                return False

            destination = result[0] if isinstance(result, (list, tuple)) else result
            shutil.copyfile(source_path, destination)
            logging.info("File saved successfully: %s -> %s", source_path, destination)
            return True
        except Exception as error:
            _log_exception("Failed to save file", error)
            return False
        finally:
            self._saving = False


def _configure_logging(debug: bool) -> None:
    """Send desktop logs to LOG_FILE at the requested level.

    core.flask_app calls basicConfig(force=True) when it is imported, which happens
    above. Without force here, basicConfig sees handlers already attached and
    returns without doing anything, so DIGITERRA_DEBUG=1 changes nothing and
    LOG_FILE stays empty.
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler()],
        force=True,
    )
    logging.getLogger("shap").setLevel(logging.WARNING)


def _log_exception(context: str, error: BaseException) -> None:
    logging.error("%s: %s", context, error)
    logging.error("Traceback:\n%s", "".join(traceback.format_exception(error)))


def _find_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _wait_for_server(host, port, timeout=10.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.5)
            if sock.connect_ex((host, port)) == 0:
                return True
        time.sleep(0.1)
    return False


def _start_server(host, port):
    try:
        app = create_app()
        app.run(host=host, port=port, debug=False, use_reloader=False)
    except Exception as error:
        _log_exception("Server failed to start", error)


def _show_error_window(message: str) -> None:
    html = f"""
    <html>
      <head><title>DiGiTerra Error</title></head>
      <body style="font-family: -apple-system, Helvetica, Arial, sans-serif; padding: 24px;">
        <h2>DiGiTerra could not start</h2>
        <p>{message}</p>
        <p>Check the log file at <code>{LOG_FILE}</code> for details.</p>
      </body>
    </html>
    """
    webview.create_window("DiGiTerra Error", html=html)
    webview.start()


def main():
    debug = os.environ.get("DIGITERRA_DEBUG") == "1"
    _configure_logging(debug)

    base_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    os.environ["DIGITERRA_BASE_DIR"] = str(base_dir)
    os.chdir(base_dir)
    output_dir = Path(
        os.environ.get(
            "DIGITERRA_OUTPUT_DIR",
            APP_SUPPORT_DIR / "user_visualizations",
        )
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    os.environ["DIGITERRA_OUTPUT_DIR"] = str(output_dir)

    host = "127.0.0.1"
    port_env = os.environ.get("DIGITERRA_PORT")
    port = int(port_env) if port_env else _find_free_port()

    api = DesktopApi(output_dir)

    try:
        server_thread = threading.Thread(
            target=_start_server,
            args=(host, port),
            daemon=True,
            name="digiterra-server",
        )
        server_thread.start()

        if not _wait_for_server(host, port):
            raise RuntimeError("Failed to start DiGiTerra server.")

        window = webview.create_window(
            "DiGiTerra",
            f"http://{host}:{port}",
            js_api=api,
            min_size=(1024, 768),
            resizable=True,
        )
        api.window = window
        webview.start(debug=debug)
    except Exception as error:
        _log_exception("Desktop app failed to launch", error)
        _show_error_window("The app encountered an unexpected error while launching.")
