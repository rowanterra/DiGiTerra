# Changelog

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed

Adversarial review of 2026-09-24 (three reviewers, one each on the routes, the pipeline and the browser side; every item below was reproduced before it was fixed, and each has a regression test in `tests/unit/test_review_2026_09_24.py`, `tests/unit/test_bundle.py` or the browser suites)

- Artifact loading: the type allowlist was a prefix test that admitted `builtins.eval`, and the loader handed skops the file's own type list as trusted, so a crafted `model.skops` ran code on load (behind the bundle signature on import, and with no signature at all in the disk session store). The allowlist is now the exact set of type names from a census of every registered estimator (`python_scripts/reporting/artifact_allowlist.txt`, written by `scripts/artifact_type_census.py`), skops is given that list and never the file's, and the disk session store signs its objects file at save and verifies it at load with the installation key.
- The guided page's default run failed for 14 of its models: a model with no editable table sent no hyperparameters and `get_model_kwargs` passed `n_estimators=None` and the like to the trainer. None keys are now dropped in both modes; the sweep script reads the private form that keeps them.
- Mean, median and mode fills included the target column, so a made-up target was trained on and scored as truth. The target is never filled; rows with a blank target are dropped.
- Binary ROC AUC scored the string labels against the second probability column, which inverted the AUC whenever the string order differed from the class order, and average precision failed on string labels and was silently omitted. Both score the estimator's positive class; the precision-recall plot gets the same positive class.
- IQR and z-score outlier removal read the one-hot columns and deleted every training row of a category under 25 percent. Binary columns are skipped by those rules.
- With feature selection on, the novelty score was never written at prediction time (shape mismatch caught and logged). Novelty is scored on the pre-selection frame by column name.
- Cross-validation ran on a different frame than the model: a deferred mean or median fill was not applied (an estimator that refuses NaN failed after the model trained), only the first of several targets was scored, and a grouped or time-ordered split plan was ignored in favour of shuffled folds (a grouped holdout of R2 -2.2 came with a CV of 0.95). CV now imputes inside each fold, scores every target, and uses GroupKFold or TimeSeriesSplit on the plan's column.
- Seed 0 was replaced by a random seed; a cleared seed, decimal-places or folds field on the guided page was sent as 0 (seed 0, no decimals, a blocked run). Seed 0 is a seed; a cleared field is sent as null and takes the default; folds are checked only when cross-validation is on.
- GaussianMixture never received the seed. GradientBoosting `warm_start` was inverted.
- "Fill with the mode" did nothing and the rows were dropped. Mode is now a deferred fill fitted on the training rows. "Remove rows with zeros" removed only rows that were zero in every scoped column; it removes a row with a zero in any of them.
- A numeric column chosen for one-hot encoding was listed twice and raised a duplicate-column error.
- Guided page: hyperparameters whose scikit-learn default is None were sent as strings (`max_depth: "3"`); integer fields truncated 2.5 to 2 and 0.5 to 0; stratifying by the target was silently dropped; two quick model changes could leave the hyperparameter table of the first model under the second; Escape did not close a tooltip opened by keyboard focus; a failed model list or a dead progress stream left the page without a message; a failed column read after a good upload was reported as an upload failure.
- The AutoML page said a blank model would be chosen by AutoML and the page sent a random forest. A blank model now compares the candidate set by cross-validation over several seeds and trains the one that scores best; the fold scores are drawn as one box per candidate (`model_comparison.png`), and the result says whether the winner is separable from the runner-up.
- Two workbook routes returned raw exception text; a spreadsheet cell starting with `= + - @` is written as text.

### Added

- Inference page: a predictor-spread figure, one box per predictor for the training rows (filled) and the rows being predicted (hatched), with rows the novelty detector marked drawn as points. The training spread is recorded by every pipeline (`training_predictor_spread.json`).
- AutoML: candidate model comparison (`python_scripts/preprocessing/model_comparison.py`).
- `scripts/adversarial_check.py`: every probe of the review as a script, with `docs/adversarial_check_2026-09-24.json` as its record; `scripts/artifact_type_census.py` writes the artifact allowlist.

Model training and inference

- Cross-validation reported RMSE and MAE with a negative sign. The summary now receives the scoring map and undoes the `neg_` prefix.
- Inference with feature selection on failed because the frame was subset before the scaler ran. Scaling now runs first, against `X_scaler.feature_names_in_`.
- Feature importance charts labeled the pre-selection column list. The artifact now records the columns the model was fit on.
- A regression run's `y_scaler` stayed in session storage and inverse-transformed the cluster labels of the next run. Non-regression runs clear the scaler, and inference checks the recorded `_digiterra_problem_type`.
- Classification with a numeric target failed because the ordinal vocabulary used `str(v)` while `y_test` kept the numeric dtype. Both sides are strings now.
- `y` was not realigned after `dropna`, so a residual NaN produced an inconsistent sample count. Both supervised pipelines realign.
- Stratify-by-bins raised `KeyError` on a hardcoded column name. The pipeline records the column the split used.
- Clustering reported a `best_k` from a silhouette sweep that the fitted model did not use, and computed agglomerative centroids at that k. `best_k` is the cluster count of the fit, and centroids come from the labels.
- Precision and recall were swapped in the fallback precision-recall curve.
- Permutation importance scored unscaled targets against a model that predicts in scaled space.
- Hyperparameter search ran twice because the fitted search object was refit.
- The run seed now reaches the random forest classifier, ElasticNet, IsolationForest, feature-selection estimators, silhouette sweep, search `random_state`, and SHAP sampling. Search CV folds are shuffled.
- Mean and median imputation, and mean or median replacement of zeros, were computed over the whole file before the train/test split, so test rows informed training values. `preprocess_data` now records those columns in a `FillPlan` (`python_scripts/preprocessing/split_fill.py`); each pipeline fits the plan on its training rows after the split, applies the same values to the test rows, and the fitted values are stored and reused at inference. Constant fills and row drops still happen before the split. The `fillna(inplace=True)` chained assignment, a silent no-op under copy-on-write, is gone.
- The regression pipeline computed the per-bin evaluation table and then returned an empty string in its place, so the "quantile Bin Results" sheet was never written. The bin labels a user types were parsed and discarded; they now name the rows of that table.
- RadiusNeighborsRegressor returned NaN for a row with no training row inside the radius. Such a row now takes the value of its nearest training row, and the model records how many rows that was.
- 67 of 67 offered estimators train from an empty hyperparameter form (`scripts/train_every_model.py`): `gamma=None` in the four SVM trainers, an empty MLP `hidden_layer_sizes`, the `n_alphas` argument removed in scikit-learn 1.9, `n_jobs` on PassiveAggressiveRegressor, and `eta0=0` on SGDClassifier. Perceptron, a classifier registered as a regressor, is a rejected entry like Polynomial.
- `prediction()` in `python_scripts/helpers.py` used the scaler's `feature_names_in_` array in a boolean `or`, which raises for more than one column, so `/predict` returned 500 for every scaled regression model. `tests/unit/test_inference.py` runs `/predict` after a regression run with and without a scaler, a random forest, a classifier, and k-means.
- The fitted preprocessor's group-map step was a closure and could not be pickled. `apply_group_map` in `python_scripts/preprocessing/utilities.py` is a module-level function with the maps passed as `kw_args`.

Web layer

- The CSV reader takes the column count from the header and caps the rows it parses at the cell budget, so a file over the limit is refused without being parsed into memory first, and the parsed frame is refused above `DIGITERRA_MAX_FRAME_MB`. The served body limit is 32 MB and the cell budget 5,000,000.
- The training request is validated in the request handler, before a thread exists, and `core/jobs.py` allows one run per session and `DIGITERRA_MAX_CONCURRENT_TRAINING` across the process. A request past either returns 429.
- The container runs gunicorn with one worker process and eight threads. An open progress stream no longer blocks other requests; `scripts/check_stream_starvation.py` measures both worker classes. A stream ends after 15 minutes without an error payload so the browser reconnects.
- The output sweep skips a session with a run in flight, refreshes a directory's age as it is used, and runs on a timer rather than only when a new session cookie is issued.
- Uploaded CSVs are removed from disk once parsed, in both the upload and prediction routes, and session output directories older than `DIGITERRA_STALE_SESSION_HOURS` (default 24) are swept when a new session is issued.
- A frame above `DIGITERRA_MAX_CELLS` cells (default 25,000,000) is rejected before it is stored; the default request-body limit is 64 MB for a served deployment, and `desktop_app.py` raises both for local use.
- `testSize`, cross-validation folds, search folds, and search iterations are bounded server-side (`core/constants.py`), and the UI inputs state the same ranges. An out-of-range value ends the run with an error instead of scheduling unbounded work.
- A progress stream answers only the browser session that started the run.
- `reset_session_scope` tolerated a token reused by the second teardown of a streamed response; it now clears the scope instead of raising.
- `GET /progress/<id>` created a tracker for any id and kept an SSE stream open for an hour. An unknown id now returns 404, and trackers are capped at 256.
- A failed training deleted the stored error with the tracker, so the client waited at a spinner until the timeout. `ProgressTracker.fail()` moves progress to the terminal value and keeps the result.
- Generated files had fixed names in one shared directory. Each session now writes to a subdirectory selected through `config.set_session_scope`, which the request and the training thread both set.
- Session cookies the server did not issue are replaced.
- The session store is bounded (32 sessions by default) and lock-guarded.
- `MAX_CONTENT_LENGTH` is set, so an oversized body is rejected before the save.
- Error handlers return JSON, so a 500 is not an HTML page the client cannot parse.
- The stratify-by-target guard accepted `[2]` and any `outputType` value.
- Desktop `save_file` accepted an absolute path from page JavaScript.
- `DIGITERRA_DEBUG=1` did nothing because `basicConfig` ran without `force=True` after the Flask app had configured logging.

Frontend

- 178 Advanced-mode controls did not respond because `templates/index.html` had 259 duplicate ids and `getElementById` returned the hidden Simple-mode twin. The Advanced copies use the `advanced*` naming and `getModeScopedElement()` resolves by mode.
- 41 hyperparameter field groups were inside a panel every code path hides. They are in the Advanced section and the unused panel is removed.
- 12 Perceptron reads used `document.getElementById('')`, and one SGD branch read an undeclared `nJobs`.
- ESLint did not extend `eslint:recommended`, so `no-undef` was off. `npm run lint` builds the bundle and lints the split files and the bundle. `npm run check-bundle` fails when the committed bundle has drifted.

### Added

- Data checks before training (`python_scripts/preprocessing/guardrails.py`): a feature identical or near-identical to the target, the target listed as a feature, a categorical column that maps one-to-one onto the class, constant and identifier columns, heavy missingness, duplicate rows, class imbalance, and too few rows for the requested split or folds. Blocking findings stop the run with the reasons unless the request sets `allowUnsafe` (Advanced, Data Checks); every finding is returned as `data_checks` and shown above the result.
- A baseline scored on the same validation rows (`python_scripts/preprocessing/baseline.py`): the training mean for regression, the most common class for classification. The result says whether the model beats it.
- Time-ordered and grouped holdouts (`python_scripts/preprocessing/splitting.py`; Advanced, Train/Test Split). Excel (`.xlsx`, `.xlsm`) and Parquet input; `GET /download/predictions.xlsx`.
- A run record per training run: `manifest.json` and `model_card.html` in the session directory, with the SHA-256 of the uploaded bytes, the request, seed, estimator and parameters, preprocessing and split, metrics, baseline, data checks, and package versions (`python_scripts/reporting/bundle.py`). `GET /export-bundle` zips the record with the fitted objects and the artifact hash. `POST /import-bundle` loads a bundle for `/predict` and is off unless `DIGITERRA_ALLOW_BUNDLE_IMPORT` is set; the desktop launcher sets it.
- `scripts/score_bundle.py` scores a new file from a bundle without the web app. `scripts/rerun_bundle.py` checks the data hash, replays the recorded request, and compares the metrics.
- Progress-stream slots: one stream per run and `DIGITERRA_MAX_CONCURRENT_STREAMS` (4) across the process, 429 past either. A process-wide budget for uploaded data, `DIGITERRA_MAX_TOTAL_FRAME_MB` (1024), evicting idle sessions first and refusing with 429 when only sessions with running jobs remain. Searches and feature-selection forests use `cpu_count // DIGITERRA_MAX_CONCURRENT_TRAINING` cores, or `DIGITERRA_JOB_CORES`.
- Bundles are signed with HMAC-SHA256 under the installation's key (`DIGITERRA_BUNDLE_KEY`, or `bundle_signing.key` generated in the app support directory); import verifies the signature before unpickling and refuses unsigned, altered, or foreign bundles. `scripts/score_bundle.py --trust-unsigned` is the command-line escape.
- Excel and Parquet files are measured before they are opened: zip member count, inflation ratio, and total inflated size for workbooks; row-group byte sizes from the footer for Parquet, which is then read in batches up to the row cap. `core.helpers.estimate_decoded_bytes` feeds the same numbers to the session budget before the parse, and fitted objects count toward the budget after each run. The desktop launcher sets limits at the scale of one machine instead of disabling them.
- The data-check override is a server-side switch (`DIGITERRA_ALLOW_UNSAFE_OVERRIDE`, on in the desktop launcher), requires `allowUnsafeReason`, and labels a forced run "not valid for decision use" in the result, manifest, and model card.
- A column selection that is not of the form `A-D` or `A-D,F,H` is refused in the browser with the offending value named; the server's fallback message states the file's column range in letters.
- One bounded zip preflight (`core.helpers.preflight_zip`) serves both the workbook reader and the bundle loader: allowed member names, member count, per-member and total decoded caps, inflation ratio, all from the central directory. `read_zip_member_bounded` streams each member and enforces the cap again, since a directory can lie. A bundle is bounded before its signature can be checked, because the signature is over bytes that must first be read.
- A fitted model is charged against the memory budget with `admit_model` after the fit; when it does not fit, the objects are dropped and the result says inference is unavailable rather than the run being discarded. The counting sink that measures the model lacked `tell`, so the previous release measured nothing.
- The Documentation view is styled after the corrplotpy comparison page: an evergreen masthead over a contour map drawn from a fixed seed by `scripts/make_doc_banner.py`, warm off-white paper, a contents box, forest-green headings, plum links, Helvetica for text and Consolas for code, and journal-style tables. Every rule is scoped to the view, so the rest of the application is unchanged.
- The Modeling page is arranged as a narrative, in the manner of KBase: a Data panel and a searchable model catalog in a left rail, and the run drawn as five numbered steps (Data, Preprocessing, Model setup, Run, Results) that advance as it proceeds. Choosing a model in the catalog sets the mode's model select. `static/js/narrative.js` builds the layout by moving the existing mode sections into a grid, so every control keeps its element id and its listeners, and reads the catalog from the model `<select>` elements so it cannot drift from the registry.
- The Data panel names the shape the server measured (rows by columns), and the run strip shows the stages the server reports as they run, so the page states what a run is doing rather than only that it is running.
- A deployment profile (`DIGITERRA_PROFILE`): `desktop`, the default, asks for no identity, no CSRF token, and no rate limit; `server` requires all three, and each still answers to its own variable. Identity is delegated to a reverse proxy through `DIGITERRA_AUTH_HEADER`, read only from an address in `DIGITERRA_TRUSTED_PROXIES`, with `DIGITERRA_SHARED_SECRET` for a deployment that has no such proxy. CSRF is a double-submit token that `static/js/core.js` echoes from every request. The rate limit is a token bucket per identity or address, where a run costs ten times a page view.
- Model artifacts are written with `skops` instead of joblib: the objects are stored as data with their types named, and loading builds only the types on an allowlist, so a bundle no longer executes what its file says. Bundle format is `digiterra-bundle/2` with `model.skops`; an older bundle's pickle is read only when `DIGITERRA_ALLOW_LEGACY_PICKLE` is set. `scripts/check_artifact_roundtrip.py` checks every registered estimator writes, reads, and predicts the same.
- `core/worker.py` runs a step in a child process under `RLIMIT_AS` and a wall clock, which is the control a budget measured inside the allocating process cannot be. Parsing goes through it under the server profile.
- A failed Excel export lost a completed classification run, because that call was the only one of the three not wrapped. It is wrapped now, as the regression and clustering exports already were.
- Session contents live behind a backend: in memory as before, or one directory per session on disk, written atomically, which lets more than one worker serve a deployment and lets a session outlive a restart. The mapping records that it has changed and is written at the end of a request and at the end of a run.
- A training queue in SQLite (`core/queue.py`): where runs wait for each other, a full slot answers 202 with a position instead of 429, `GET /queue/<id>` says where a run stands, a freed slot starts the oldest waiting run, and a job whose worker stopped returns to the queue rather than sitting as running.
- MIT license.
- This changelog.
- Makefile with `install`, `dev`, `lint`, `test`, `check`, and `build-bundle` targets.
- ruff configuration in `pyproject.toml` and a CI matrix over Python 3.11 and 3.12.

### Changed

- `requirements.txt` pins every package to the version recorded by `pip freeze`. `requests` is removed because nothing imports it.
- `docs/SECURITY_REVIEW.md` describes the current upload, download, and session handling.
- `docs/HANDOFF.md`, `docs/SOFTWARE_ALIGNMENT.md`, `docs/ARCHITECTURE_RECOMMENDATIONS.md`, and `docs/CLEANUP_CHECKLIST.md` are removed. The still-true content is in `docs/documentation.md` and `CONTRIBUTING.md`.
- Helm chart `appVersion` is 0.1.0, and `image.repository` has no default.
