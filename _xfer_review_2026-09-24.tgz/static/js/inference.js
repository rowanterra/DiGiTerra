/**
 * Inference tab: prediction form, AutoML/advanced forms. Depends on core.js.
 */
predictionForm.addEventListener('submit', async (e) => {
    e.preventDefault()
    let predictionErrorDiv = document.getElementById('predictionErrorDiv')
    let uploadPredictDf = document.getElementById('uploadPredictDf')
    let predictionResults = document.getElementById('predictionResults')

    //const predictFile = document.getElementById('predictFile').files[0];
    const formData = new FormData(predictionForm);
    formData.append('indicators', 'indicators')
    const resultTimestamp = formatDateTimeForFilename() 
    const predictionDownloadName = `predictions_${resultTimestamp}.csv`

    try{
        const response = await fetch('/predict', {
            method: 'POST',
            body: formData,
        });
        let data = await response.json();
        if (response.ok === true) {
            predictionErrorDiv.classList.add('hidden')
            predictionResults.classList.remove('hidden')
            const summary = data.summary || [];
            const preview = data.predictions_preview || {};
            const trainingViz = data.training_visualization;
            const trainingVizVersion = data.training_visualization_version || Date.now();
            const inferenceViz = data.inference_visualization;
            const inferenceVizVersion = data.inference_visualization_version || Date.now();
            let trainingVizUrl = '';
            let trainingPerfUrl = '';
            let trainingPlotWithOverlayUrl = ''; // for regression: pred-vs-actual only (no composite) so overlay aligns
            let inferenceVizUrl = ''; // server-regenerated plot with train + test + inference points (no overlay)
            if (trainingViz) {
                const base = withApiRoot('/user-visualizations/' + trainingViz);
                const cacheQuery = '?v=' + encodeURIComponent(trainingVizVersion) + '&t=' + Date.now();
                trainingVizUrl = base + cacheQuery;
                let predActualName = trainingViz;
                const modelTypeForPerf = data.model_type || 'regression';
                if (modelTypeForPerf === 'regression') {
                    predActualName = predActualName
                        .replace('target_plot_1_advanced', 'target_plot_pred_actual_1_advanced')
                        .replace('target_plot_1', 'target_plot_pred_actual_1');
                    trainingPlotWithOverlayUrl = withApiRoot('/user-visualizations/' + predActualName) + cacheQuery;
                }
                trainingPerfUrl = withApiRoot('/user-visualizations/' + predActualName) + cacheQuery;
            }
            if (inferenceViz) {
                inferenceVizUrl = withApiRoot('/user-visualizations/' + inferenceViz) + '?v=' + encodeURIComponent(inferenceVizVersion) + '&t=' + Date.now();
            }
            const modelType = data.model_type || 'regression';
            const modelTypeLabel = modelType === 'classification' ? 'Classification' : modelType === 'cluster' ? 'Clustering' : 'Regression';

            let summaryTableHtml = '';
            if (summary.length > 0) {
                const numericKeys = ['column', 'n', 'min', 'max', 'mean', 'std', '25', '50', '75', '100'];
                const hasNumeric = summary.some(row => row.mean != null || row.min != null);
                if (hasNumeric) {
                    summaryTableHtml = `
                        <table class="stats-table model-stats-table">
                            <thead><tr>${numericKeys.map(k => `<th>${k === '25' ? '25%' : k === '50' ? '50%' : k === '75' ? '75%' : k === '100' ? '100%' : k}</th>`).join('')}</tr></thead>
                            <tbody>
                                ${summary.filter(r => r.mean != null || r.min != null).map(row => `
                                    <tr>${numericKeys.map(k => `<td>${row[k] != null ? (typeof row[k] === 'number' ? Number(row[k]).toFixed(4) : escapeHtml(String(row[k]))) : ''}</td>`).join('')}</tr>
                                `).join('')}
                            </tbody>
                        </table>`;
                } else {
                    summaryTableHtml = summary.map(row => `
                        <div style="margin-bottom: 12px;">
                            <strong>${escapeHtml(row.column)}</strong> (n=${row.n})
                            ${row.value_counts && row.value_counts.length ? `
                                <table class="stats-table model-stats-table" style="margin-top: 6px;">
                                    <tr><th>Value</th><th>Count</th></tr>
                                    ${row.value_counts.map(vc => `<tr><td>${escapeHtml(vc.value)}</td><td>${vc.count}</td></tr>`).join('')}
                                </table>
                            ` : ''}
                        </div>
                    `).join('');
                }
            } else {
                summaryTableHtml = '<p>No inference summary available.</p>';
            }

            let previewChartHtml = '';
            const firstCol = summary.length ? summary[0].column : null;
            const trainingSummaryForAxes = data.training_target_summary && data.training_target_summary.summary;
            const axisMin = (trainingSummaryForAxes && trainingSummaryForAxes[0] && (trainingSummaryForAxes[0].min != null || trainingSummaryForAxes[0]['25'] != null))
                ? (Number(trainingSummaryForAxes[0].min) ?? Number(trainingSummaryForAxes[0]['25']))
                : null;
            const axisMax = (trainingSummaryForAxes && trainingSummaryForAxes[0] && (trainingSummaryForAxes[0].max != null || trainingSummaryForAxes[0]['100'] != null))
                ? (Number(trainingSummaryForAxes[0].max) ?? Number(trainingSummaryForAxes[0]['100']))
                : null;
            if (firstCol && preview[firstCol] && preview[firstCol].length > 0 && typeof preview[firstCol][0] === 'number') {
                const vals = preview[firstCol];
                const min = Math.min(...vals);
                const max = Math.max(...vals);
                const lo = (axisMin != null && axisMax != null) ? Math.min(axisMin, min) : min;
                const hi = (axisMax != null && axisMin != null) ? Math.max(axisMax, max) : max;
                const range = hi - lo || 1;
                const bins = 10;
                const step = (max - min) / bins || 1;
                const counts = Array(bins).fill(0);
                vals.forEach(v => {
                    let i = Math.min(Math.floor((v - min) / step), bins - 1);
                    if (i < 0) i = 0;
                    counts[i]++;
                });
                const maxCount = Math.max(...counts, 1);
                const histPad = { left: 42, right: 16, top: 12, bottom: 36 };
                const histW = 280;
                const histH = 200;
                const histPlotW = histW - histPad.left - histPad.right;
                const histPlotH = histH - histPad.top - histPad.bottom;
                const histBarsSvg = counts.map((c, i) => {
                    const barH = maxCount > 0 ? (c / maxCount) * histPlotH : 0;
                    const x = histPad.left + (i / bins) * histPlotW;
                    const bw = Math.max(2, histPlotW / bins - 2);
                    const y = histPad.top + histPlotH - barH;
                    return `<rect x="${x}" y="${y}" width="${bw}" height="${barH}" fill="#7f8c9a" rx="2"/>`;
                }).join('');
                const histYTicks = [0, Math.round(maxCount / 2), maxCount].filter((v, i, a) => a.indexOf(v) === i);
                const histYTickLines = histYTicks.map(t => {
                    const y = histPad.top + histPlotH - (t / maxCount) * histPlotH;
                    return `<line x1="${histPad.left}" y1="${y}" x2="${histPad.left - 5}" y2="${y}" stroke="#444" stroke-width="1"/>`;
                }).join('');
                const xTickCount = 5;
                const xTickValues = [];
                for (let i = 0; i < xTickCount; i++) {
                    const v = min + (max - min) * (i / (xTickCount - 1));
                    xTickValues.push(v);
                }
                const xTickLines = xTickValues.map((v) => {
                    const t = (v - min) / (max - min || 1);
                    const x = histPad.left + t * histPlotW;
                    return `<line x1="${x}" y1="${histPad.top + histPlotH}" x2="${x}" y2="${histPad.top + histPlotH + 5}" stroke="#444" stroke-width="1"/>`;
                }).join('');
                const xTickTexts = xTickValues.map((v) => {
                    const t = (v - min) / (max - min || 1);
                    const x = histPad.left + t * histPlotW;
                    const label = (v === Math.floor(v) ? v : Number(v).toFixed(1)).toString();
                    return `<text x="${x}" y="${histH - 10}" text-anchor="middle" font-size="10" fill="#444">${label}</text>`;
                }).join('');
                const leftPlotHtml = (trainingViz || inferenceVizUrl) ? (() => {
                    // Prefer server-regenerated plot (train + test + inference) when present; else training image + overlay.
                    if (inferenceVizUrl) {
                        return `
                        <div style="position: relative; display: inline-block; max-width: 100%;">
                            <img src="${inferenceVizUrl}" alt="Predicted vs Actual (train, test, inference)" class="inference-model-graphic-img inference-training-plot-img" style="display: block; max-height: 300px; width: auto;">
                        </div>
                        <p style="margin: 4px 0 0 0; font-size: 0.8rem; color: #555;">Pink points = inference (predicted values only; we have no actuals for new data). Distribution to the right.</p>`;
                    }
                    const imgUrl = trainingPlotWithOverlayUrl || trainingVizUrl;
                    const toNormX = v => 10 + ((v - lo) / range) * 80;
                    const toNormY = v => 85 - ((v - lo) / range) * 75;
                    const overlayPoints = vals.map(v => {
                        const cx = toNormX(v);
                        const cy = toNormY(v);
                        return `<circle cx="${cx}" cy="${cy}" r="0.38" fill="#5a7a9a" opacity="0.5"/>`;
                    }).join('');
                    return `
                        <div style="position: relative; display: inline-block; max-width: 100%;">
                            <img src="${imgUrl}" alt="Training Predicted vs Actual" class="inference-model-graphic-img inference-training-plot-img" style="display: block; max-height: 300px; width: auto;">
                            <svg class="inference-overlay-svg" style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; pointer-events: none;" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">${overlayPoints}</svg>
                        </div>
                        <p style="margin: 4px 0 0 0; font-size: 0.8rem; color: #555;">Same plot as Modeling page; inference points (gray) on diagonal.</p>`;
                })() : '';
                const inferenceDistLabel = 'Inference distribution';
                previewChartHtml = `
                    <h4 style="margin: 0 0 8px 0;">Inference visuals (${escapeHtml(firstCol)})</h4>
                    <p style="margin: 0 0 10px 0; font-size: 0.9rem; color: #666;">Training Predicted vs Actual with inference points overlaid (left); inference distribution (right).</p>
                    <div class="inference-visuals-row" style="display: flex; flex-wrap: wrap; gap: 20px; align-items: flex-start;">
                        ${(trainingViz || inferenceVizUrl) ? `<div class="inference-training-plot-wrap" style="flex: 0 1 320px; min-width: 200px;"><p style="margin: 0 0 6px 0; font-size: 0.85rem; font-weight: 600;">${inferenceVizUrl ? 'Predicted vs Actual (training + inference)' : 'Training plot + inference overlay'}</p>${leftPlotHtml}</div>` : ''}
                        <div class="inference-dist-wrap" style="flex: 1 1 280px; min-width: 200px;">
                            <p style="margin: 0 0 6px 0; font-size: 0.85rem; font-weight: 600;">${inferenceDistLabel}</p>
                            <svg width="${histW}" height="${histH}" viewBox="0 0 ${histW} ${histH}" class="inference-dist-svg" style="max-width: 100%; height: auto;">
                                ${histBarsSvg}
                                <line x1="${histPad.left}" y1="${histPad.top}" x2="${histPad.left}" y2="${histPad.top + histPlotH}" stroke="#333" stroke-width="1"/>
                                <line x1="${histPad.left}" y1="${histPad.top + histPlotH}" x2="${histPad.left + histPlotW}" y2="${histPad.top + histPlotH}" stroke="#333" stroke-width="1"/>
                                ${histYTickLines}
                                ${histYTicks.map(t => `<text x="${histPad.left - 8}" y="${histPad.top + histPlotH - (t / maxCount) * histPlotH + 4}" text-anchor="end" font-size="10" fill="#444">${t}</text>`).join('')}
                                ${xTickLines}${xTickTexts}
                                <text x="${histPad.left + histPlotW/2}" y="${histH - 2}" text-anchor="middle" font-size="10" fill="#444">Predicted units</text>
                                <text x="14" y="${histPad.top + histPlotH/2}" text-anchor="middle" font-size="10" fill="#444" transform="rotate(-90, 14, ${histPad.top + histPlotH/2})">Count</text>
                            </svg>
                        </div>
                    </div>
                    <p style="margin-top: 8px; font-size: 0.85rem; color: #666;">Range: ${min.toFixed(4)} – ${max.toFixed(4)} (${vals.length} points)</p>
                `;
            }
            // Classification: predicted class counts are already in the summary table; no duplicate "Inference distribution" block

            const numericKeysForPanels = ['column', 'n', 'min', 'max', 'mean', 'std', '25', '50', '75', '100'];
            const trainingSummaryForPanel = data.training_target_summary && data.training_target_summary.summary;

            const classificationNote = modelType === 'classification' ? `
                <p class="inference-classification-note" style="margin: 0 0 12px 0; font-size: 0.9rem; color: #555; font-style: italic;">No true labels for new data, so we only show predicted class counts below and the model's test-set performance (confusion matrix) on the right.</p>
            ` : '';

            function renderSummaryTable(rows, numericKeys) {
                if (!rows || rows.length === 0) return '<p>No data.</p>';
                const hasNumeric = rows.some(r => r.mean != null || r.min != null);
                if (hasNumeric) {
                    return `<table class="stats-table model-stats-table"><thead><tr>${numericKeys.map(k => `<th>${k === '25' ? '25%' : k === '50' ? '50%' : k === '75' ? '75%' : k === '100' ? '100%' : k}</th>`).join('')}</tr></thead><tbody>
                        ${rows.filter(r => r.mean != null || r.min != null).map(row => `
                            <tr>${numericKeys.map(k => `<td>${row[k] != null ? (typeof row[k] === 'number' ? Number(row[k]).toFixed(4) : escapeHtml(String(row[k]))) : ''}</td>`).join('')}</tr>
                        `).join('')}
                    </tbody></table>`;
                }
                return rows.map(row => `
                    <div style="margin-bottom: 8px;">
                        <strong>${escapeHtml(row.column)}</strong> (n=${row.n})
                        ${row.value_counts && row.value_counts.length ? `
                            <table class="stats-table model-stats-table" style="margin-top: 4px;"><tr><th>Value</th><th>Count</th></tr>
                                ${row.value_counts.map(vc => `<tr><td>${escapeHtml(vc.value)}</td><td>${vc.count}</td></tr>`).join('')}
                            </table>
                        ` : ''}
                    </div>
                `).join('');
            }
            const _numericKeys = ['column', 'n', 'min', 'max', 'mean', 'std', '25', '50', '75', '100'];
            const trainingSummaryTableHtml = trainingSummaryForPanel && trainingSummaryForPanel.length ? `
                <h3 style="margin: 0 0 8px 0;">Training data (target)</h3>
                <p style="margin: 0 0 12px 0; font-size: 0.95rem; color: #666;">Spread the model was built on.</p>
                <div class="model-stats-table-wrapper" style="margin-bottom: 20px;">${renderSummaryTable(trainingSummaryForPanel, numericKeysForPanels)}</div>
            ` : '';
            // Two graphics share one frame: the trained model's performance, and the
            // spread of every predictor in the training rows against the rows just
            // predicted (the check that the new data lies where the model was fitted).
            const spreadUrl = data.spread_visualization
                ? withApiRoot('/user-visualizations/' + data.spread_visualization) + '?v=' + encodeURIComponent(data.spread_visualization_version || Date.now())
                : '';
            const perfUrl = trainingViz ? (trainingPerfUrl || trainingVizUrl) : '';
            const graphicChoices = [
                spreadUrl ? { key: 'spread', label: 'Predictor spread: training rows against new rows', url: spreadUrl, alt: 'Predictor spread of training rows and new rows' } : null,
                perfUrl ? { key: 'performance', label: 'Model used (training performance)', url: perfUrl, alt: 'Training performance' } : null,
            ].filter(Boolean);
            const imgStyle = 'display: block; max-height: calc(100vh - var(--header-offset, 88px) - 360px); width: auto; max-width: 100%; object-fit: contain;';
            const modelGraphicSectionHtml = graphicChoices.length ? `
                <h3 style="margin: 0 0 8px 0;">Graphic</h3>
                <label for="inferenceGraphicSelect" class="sr-only">Select graphic</label>
                <select id="inferenceGraphicSelect" style="margin: 0 0 8px 0; max-width: 100%;">
                    ${graphicChoices.map(g => `<option value="${g.key}">${escapeHtml(g.label)}</option>`).join('')}
                </select>
                <img id="inferenceGraphic" src="${graphicChoices[0].url}" alt="${escapeHtml(graphicChoices[0].alt)}" class="inference-model-graphic-img" style="${imgStyle}">
            ` : '';
            const rightPanelHtml = (trainingSummaryTableHtml || modelGraphicSectionHtml) ? `
                <div class="inference-model-graphic" style="flex: 0 0 calc(50% - 12px); min-width: 200px; overflow: auto; align-self: flex-start;">
                    ${modelGraphicSectionHtml}
                    ${trainingSummaryTableHtml}
                </div>
            ` : '';

            predictionResults.innerHTML = `
                <h2>Inference Results</h2>
                <p class="inference-model-type" style="margin: 0 0 16px 0; font-size: 0.95rem; color: #555;"><strong>Model type:</strong> ${escapeHtml(modelTypeLabel)}</p>
                <p>Your inference results for '<strong>${escapeHtml(data.filename || 'file')}</strong>' are ready to download.</p>
                <div class="button-group" style="margin-bottom: 24px;">
                    <a href="${withApiRoot('/download/predictions.csv')}?download_name=${encodeURIComponent(predictionDownloadName)}" onclick="return downloadFile('predictions.csv', '${predictionDownloadName}')">
                        <button class="predictionresultButton export-button">Download Results CSV</button>
                    </a>
                    <button class="secondary-button" onclick="backToModel()">Back to Modeling</button>
                    <button class="secondary-button" onclick="newPredict()">Run inference on another dataset</button>
                </div>
                <div class="inference-results-content" style="display: flex; flex-wrap: nowrap; gap: 24px; align-items: flex-start;">
                    <div class="inference-summary-section" style="flex: 0 0 calc(50% - 12px); min-width: 200px; overflow: auto; align-self: flex-start;">
                        <h3 style="margin: 0 0 8px 0;">Inference summary</h3>
                        <p style="margin: 0 0 12px 0; font-size: 0.95rem; color: #666;">Descriptive statistics for inferred (predicted) values (same style as Data Exploration).</p>
                        ${classificationNote}
                        <div class="model-stats-table-wrapper" style="margin-bottom: 16px;">${summaryTableHtml}</div>
                        ${previewChartHtml ? `<div class="inference-preview-chart" style="margin-top: 16px;">${previewChartHtml}</div>` : ''}
                    </div>
                    ${rightPanelHtml}
                </div>
            `
            showApplicabilityLine(data.applicability_summary)
            showUncertaintyLine(data.uncertainty_summary)
            // The example rows were drawn from a known species each, so the page can
            // say how many came back the way they were drawn. Only for those rows:
            // a person's own file has no key to compare against.
            if (window.digiterraExampleRows) {
                window.digiterraExampleRows = false
                showExampleRowAgreement(preview)
            }
            const graphicSelect = document.getElementById('inferenceGraphicSelect')
            if (graphicSelect) {
                graphicSelect.addEventListener('change', () => {
                    const g = graphicChoices.find(x => x.key === graphicSelect.value)
                    const img = document.getElementById('inferenceGraphic')
                    if (g && img) { img.src = g.url; img.alt = g.alt }
                })
            }
            uploadPredictDf.classList.add('hidden')
        }
        else {
            predictionErrorDiv.classList.remove('hidden')
            // Sanitize error message to prevent XSS
            const safeError = escapeHtml(String(data.error || 'Unknown error'));
            predictionErrorDiv.innerHTML = `<p>Error: ${safeError}</p>`
            predictionResults.classList.add('hidden')
        }
    }
    catch (e) {
        predictionErrorDiv.classList.remove('hidden')
        // Sanitize error message to prevent XSS
        const safeError = escapeHtml(String(e));
        predictionErrorDiv.innerHTML = `<p>Error: ${safeError}</p>`
    }
    


});

// AutoML form submission handler
const automlForm = document.getElementById('automlForm');
if (automlForm) {
    automlForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // AutoML mode is selected - trigger processForm submission with AutoML defaults
        // The processForm handler will detect AutoML mode and set appropriate defaults
        const automlModeRadio = document.getElementById('automlMode');
        if (automlModeRadio) {
            automlModeRadio.checked = true;
            switchModelingMode('automl');
        }
        
        // Check if processForm exists
        if (!processForm) {
            const errorDiv = getCachedElement('errorDiv');
            if (errorDiv) {
                showError(errorDiv, 'DiGiTerra has no model configuration. Configure the data first.');
                errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            return;
        }
        
        // Disable the submit button and show initial status
        const submitButton = document.getElementById('automlSubmitButton');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Running AutoML...';
        }
        
        // Show loading indicator immediately with enhanced visibility
        const automlLoading = document.getElementById('automlLoading');
        if (automlLoading) {
            automlLoading.classList.remove('hidden');
            automlLoading.style.display = 'block';
            automlLoading.innerHTML = `
                <div style="padding: 24px; background-color: #fff3cd; border: 2px solid #ffc107; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <p style="font-size: 1.3em; font-weight: 700; margin-bottom: 12px; color: #856404; display: flex; align-items: center; gap: 10px;">
                        <span>AutoML is running...</span>
                    </p>
                    <p style="color: #856404; margin-bottom: 16px; font-size: 1.05em;">Setting up automated model selection and optimization. This may take several hours for large datasets.</p>
                    <div class="spinner" style="margin: 0 auto; border-top-color: #856404;"></div>
                    <p style="color: #666; margin-top: 16px; font-size: 0.95em; font-style: italic;">Progress updates will appear here as AutoML evaluates different models and configurations.</p>
                </div>
            `;
        }
        
        // Show stop button
        const stopButton = document.getElementById('stopAutomlButton');
        if (stopButton) stopButton.style.display = 'inline-block';
        
        // Programmatically trigger the processForm submission
        // processForm will detect AutoML mode and set defaults
        const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
        processForm.dispatchEvent(submitEvent);
        
        // Note: Button will be re-enabled by processForm handler when complete or on error
    });
}

// Advanced Optimization forms (unified Modeling tab + legacy full-page panel) — same training flow as processForm
function wireAdvancedOptimizationFormSubmit(form) {
    if (!form) return;
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Switch to Advanced mode if not already selected
        const advancedModeRadio = document.getElementById('advancedMode');
        if (advancedModeRadio && !advancedModeRadio.checked) {
            advancedModeRadio.checked = true;
            switchModelingMode('advanced');
        }

        // Check if a model has been selected
        const advancedNModels = getCachedElement('advancedNModels');
        const advancedClModels = getCachedElement('advancedClModels');
        const advancedClassModels = getCachedElement('advancedClassModels');

        const selectedModel = advancedNModels?.value || advancedClModels?.value || advancedClassModels?.value;

        if (!selectedModel) {
            const errorDiv = getCachedElement('errorDiv');
            if (errorDiv) {
                showError(errorDiv, 'Select a model before you run with advanced options.');
                errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            return;
        }

        if (!processForm) {
            const errorDiv = getCachedElement('errorDiv');
            if (errorDiv) {
                showError(errorDiv, 'DiGiTerra has no model configuration. Configure the data first.');
                errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            return;
        }

        const submitter = e.submitter;
        const submitButton = (submitter && submitter.tagName === 'BUTTON' && submitter.getAttribute('type') === 'submit')
            ? submitter
            : form.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Running...';
        }

        const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
        processForm.dispatchEvent(submitEvent);

        setTimeout(() => {
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = 'Run Model with Advanced Options';
            }
        }, 1000);
    });
}
wireAdvancedOptimizationFormSubmit(document.getElementById('advancedOptimizationForm'));
wireAdvancedOptimizationFormSubmit(document.getElementById('advancedOptimizationLegacyForm'));


// Bundle import is available where the server allows it (desktop builds). The
// form stays hidden until a probe of /import-bundle says the route accepts uploads.
(function wireBundleImport() {
    const form = document.getElementById('importBundleForm');
    if (!form) return;
    fetch('/import-bundle', { method: 'POST', body: new FormData() })
        .then(r => { if (r.status !== 403) form.classList.remove('hidden'); })
        .catch(() => {});
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const status = document.getElementById('importBundleStatus');
        status.textContent = 'Loading bundle...';
        try {
            const response = await fetch('/import-bundle', { method: 'POST', body: new FormData(form) });
            const data = await response.json();
            if (!response.ok) {
                status.textContent = data.error || 'DiGiTerra cannot load the bundle.';
                return;
            }
            const model = data.model || {};
            const features = Array.isArray(model.features) ? model.features.join(', ') : '';
            status.textContent = `Loaded ${model.name || 'model'} (${model.problem_type || ''}) trained ${data.created_at || ''}. Features: ${features}. ${data.note || ''}`;
        } catch (err) {
            status.textContent = 'DiGiTerra cannot load the bundle.';
        }
    });
})();


/* How many of the example rows came back as the species they were drawn from.

   penguins_new_key.csv holds one species per row_id, and predictions.csv keeps the
   order of the file it scored, so the two line up row for row. The count is a
   sanity check on the run rather than a score: the rows are synthetic. */
async function showExampleRowAgreement(preview) {
    try {
        const predictedKey = Object.keys(preview).find((k) => k.startsWith('Predicted_'))
        if (!predictedKey) return
        const predicted = preview[predictedKey]
        const response = await fetch(`${API_ROOT}/example-data/penguins_new_key.csv`)
        if (!response.ok) return
        const rows = (await response.text()).trim().split('\n').slice(1)
        const expected = rows.map((line) => line.split(',')[1].trim())
        if (!expected.length || expected.length !== predicted.length) return
        let agree = 0
        for (let i = 0; i < expected.length; i += 1) {
            if (String(predicted[i]).trim() === expected[i]) agree += 1
        }
        const host = document.querySelector('.inference-summary-section')
        if (!host) return
        const line = document.createElement('p')
        line.id = 'exampleRowAgreement'
        line.className = 'field-note'
        line.textContent = `${agree} of ${expected.length} rows match the species each row was drawn from.`
        host.appendChild(line)
    } catch (err) {
        console.error('Could not compare the example rows with the key:', err)
    }
}


/* One line saying how many of these predictions rest on data the model has seen.
   A model answers for any row whose columns parse, and nothing else on the page
   separates a prediction on familiar data from one on a row nothing like it. */
function showApplicabilityLine(summary) {
    if (!summary || !summary.rows) return
    const host = document.querySelector('.inference-summary-section')
    if (!host) return
    const line = document.createElement('p')
    line.id = 'applicabilitySummary'
    line.className = 'field-note'
    const outOfRange = summary.out_of_range === 1
        ? '1 row has a value outside the training range.'
        : `${summary.out_of_range} rows have a value outside the training range.`
    line.textContent = summary.novel === 0
        ? `No row scores as unlike the training data. ${outOfRange}`
        : `${summary.novel} of ${summary.rows} rows score as unlike the training data. ${outOfRange}`
    host.appendChild(line)
}


/* One line on how much to trust a single prediction: the interval's half-width for a
   regression run, or the least confident prediction for a classifier. */
function showUncertaintyLine(summary) {
    if (!summary) return
    const host = document.querySelector('.inference-summary-section')
    if (!host) return
    let text = ''
    if (summary.kind === 'interval' && summary.half_width !== null && summary.half_width !== undefined) {
        const units = summary.units ? ` ${summary.units}` : ''
        text = `${summary.coverage}% intervals are half-width ${summary.half_width.toPrecision(4)}${units}.`
    } else if (summary.kind === 'probability' && summary.lowest !== null && summary.lowest !== undefined) {
        text = `Lowest class probability among predictions is ${summary.lowest.toFixed(3)}.`
    }
    if (!text) return
    const line = document.createElement('p')
    line.id = 'uncertaintySummary'
    line.className = 'field-note'
    line.textContent = text
    host.appendChild(line)
}
